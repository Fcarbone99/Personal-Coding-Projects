<aside class="aside bg-light p-3">
    <h3>Related Links</h3>
    <ul class="list-unstyled">
        <li><a href="#" class="aside-link">Resource 1</a></li>
        <li><a href="#" class="aside-link">Resource 2</a></li>
        <li><a href="#" class="aside-link">Resource 3</a></li>
    </ul>
</aside>