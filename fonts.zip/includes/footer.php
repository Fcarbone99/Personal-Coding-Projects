<footer class="text-white text-center p-3 fixed-bottom">
    <p>&copy; 2024 The Movement Collective. All rights reserved.</p>
</footer>