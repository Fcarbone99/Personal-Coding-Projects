<div class="container mt-3">
    <h2>Main Content</h2>
    <div class="card">
        <div class="card-body">
            <p>This is the main content area. It adjusts based on the device size.</p>
        </div>
    </div>
</div>