                    <div class="container mt-3">
                      <h2>Play Audio</h2>
                      <div class="card">
                        <div class="card-body">

                          <p>Press play and wait for the audio to end.</p>

                          <audio id="myAudio" controls>
                            <source src="../audios/horse.ogg" type="audio/ogg">
                            <source src="../audios/horse.mp3" type="audio/mpeg">
                            Your browser does not support the audio element.
                          </audio>

                        </div>
                      </div>
                    </div>